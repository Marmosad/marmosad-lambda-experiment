"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PLAYER_COUNT_LOWER_BOUND = 3;
exports.PLAYER_COUNT_UPPER_BOUND = 10;
